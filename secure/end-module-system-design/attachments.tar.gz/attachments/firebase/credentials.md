# Firebase Console credentials

user: ssdcs2022@gmail.com

password: SecureSSDCS2022@!


# Default users

|email            |password|user|type     |
|-----------------|--------|----|---------|
|aalcorn@home.cern|123456  |A001|ADMIN    |
|phigg@home.cern  |123456  |S001|SCIENTIST|
|kbouman@home.cern|123456  |S002|SCIENTIST|
