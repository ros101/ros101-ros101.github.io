#!/bin/sh

docker-compose -f docker-compose-infra.yml up