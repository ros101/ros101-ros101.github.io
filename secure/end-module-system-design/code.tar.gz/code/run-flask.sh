#!/bin/sh

python3 containers/app/main.py