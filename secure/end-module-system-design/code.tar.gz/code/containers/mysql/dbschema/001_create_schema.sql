--
-- MyMONIT DB Schema definition
-- 
--
-- schema definition

create schema my_monit;