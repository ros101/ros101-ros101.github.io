'''Start the application'''

from my_monit.app import init

if __name__ == "__main__":
    init()
